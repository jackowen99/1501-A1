// Jack Owen
import java.io.*;
import java.util.*;

public class Crossword 
{
    static TrieSTNew<String> dictionary = new TrieSTNew<String>();
    static char[][] gameBoard; // crossword board
    static int totalSolutions = 0; // # of total crossword solutions
    static int boardWidth; // used for the board dimensions
    static StringBuilder[] rows;
    static StringBuilder[] cols;
    final int WRD = 1;
    final int PRFX = 2;
    final int BOTH = 3;

    public static void main(String[] args) throws IOException 
    {

        new Crossword(args);

    }

    public Crossword(String[] args) throws IOException {
        //System.out.println(totalSolutions);
        Scanner fScan = new Scanner(new FileInputStream(args[0]));

        Scanner read = new Scanner(new File(args[1]));

        int boardWidth = Integer.parseInt(read.nextLine());

        gameBoard = new char[boardWidth][boardWidth];

        for (int r = 0; r < boardWidth; r++) {
            String current = read.nextLine();
            for (int c = 0; c < boardWidth; c++) {
                gameBoard[r][c] = current.charAt(c);
            }
        }

        read.close();

        String str;
        while (fScan.hasNext()) {
            str = fScan.next();
            if (str.length() <= boardWidth) {
                dictionary.put(str, str);
            }
        }


        cols = new StringBuilder[boardWidth];

        rows = new StringBuilder[boardWidth];

        for (int i = 0; i < boardWidth; i++) {
            cols[i] = new StringBuilder();
            rows[i] = new StringBuilder();
        }

        play(0, 0);

        System.out.print("There were " + totalSolutions + " found!");

    }

    public void play(int r, int c) // backtracks uses pruning to find all answers for a given crossword board
    {
        //System.out.println(gameBoard.length);
        if (r == gameBoard.length) {
            if (totalSolutions <= 10000) {
                System.out.println("Solution: " + totalSolutions);
                boardSolution();
            }

            totalSolutions++;
            return;
        }

        if (gameBoard[r][c] == '-') {
            rows[r].append('-');
            cols[c].append('-');
            if (c + 1 < gameBoard.length) {
                play(r, c + 1);

            } else {
                play(r + 1, 0);
            }
            rows[r].deleteCharAt(rows[r].length() - 1);
            cols[c].deleteCharAt(cols[c].length() - 1);
        } else {
            for (char ch = 'a'; ch <= 'z'; ch++) {
                if (checkPrfx(r, c, ch)) {
                    if (gameBoard[r][c] != '+') {

                        ch = gameBoard[r][c];
                    }
                    rows[r].append(ch);
                    cols[c].append(ch);

                    if (c + 1 < gameBoard.length) {

                        play(r, c + 1);
                    } else {
                        play(r + 1, 0);
                    }
                    rows[r].deleteCharAt(rows[r].length() - 1);
                    cols[c].deleteCharAt(cols[c].length() - 1);

                }
            }
        }
    }

    public boolean checkPrfx(int row, int col, char ch)
       {

            if(row < gameBoard.length && col < gameBoard.length)
            {
                if(gameBoard[row][col] != '+')
                {
                    ch = gameBoard[row][col];
                }
               
             
                rows[row].append(ch);
                cols[col].append(ch);

            }

            else
            {
                return false;
            }
      
            String[] wordsInRow = rows[row].toString().split("-");
            String[] wordsInCol = cols[col].toString().split("-");
            rows[row].deleteCharAt(rows[row].length()-1);
            cols[col].deleteCharAt(cols[col].length()-1);  
            Boolean colIsValid = checkWord(wordsInRow, col);
            Boolean rowIsValid = checkWord(wordsInCol, row);
            return colIsValid && rowIsValid;
       }

    public void boardSolution()
    {
        for (int i = 0; i < rows.length; i++)
        {
            System.out.println(rows[i]);
        }
            
        System.out.println();
    }       
    
    public boolean checkWord(String[] arr, int num) // checks to see if a word is created or not
    {
        boolean isWord = true;
        
        for (int i = 0; i < arr.length; i++)
        {
            int ans = dictionary.searchPrefix(arr[i].toString());
            
            if(arr[i].length() == 0)
            {
                continue;
            } 
        
            if(i < arr.length - 1 || num + 1 == gameBoard.length)
            {
                isWord = (ans == WRD || ans == BOTH);
            }
            
            else
            {
                if (ans != PRFX && ans != BOTH) 
                {
                    isWord = false;
                }
        
            }
            
            if(isWord == false) 
            {
                return false;
            }    

        }
        return isWord;
    }
}
