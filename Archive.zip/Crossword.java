import java.io.*;
import java.util.*;

public class Crossword {
    static int boardWidth;
    static int totalSolutions = 0;
    static char[][] gameBoard;
    static StringBuilder[] rows;
    static StringBuilder[] cols;
    final int PRFX = 1;
    final int WRD = 2;
    final int BOTH = 3;
    static TrieSTNew<String> dictionary = new TrieSTNew<String>();

    public static void main(String[] args) throws IOException {

        new Crossword(args);

    }

    public Crossword(String[] args) throws IOException {
      
        Scanner fScan = new Scanner(new FileInputStream(args[0])); // for dictionary

        Scanner read = new Scanner(new File(args[1])); // for crossword game board

        int boardWidth = Integer.parseInt(read.nextLine()); // width of board or dimensions of board

        gameBoard = new char[boardWidth][boardWidth]; // creates crossword board

        for (int i = 0; i < boardWidth; i++) {
            String curr = read.nextLine();
            for (int j = 0; j < boardWidth; j++) {

                gameBoard[i][j] = curr.charAt(j);
            }
        }
        read.close();

        String st;
        while (fScan.hasNext()) { // new TrieSTNew string and adds stuff from file to the trie
            st = fScan.next();
            if (st.length() <= boardWidth) {
                dictionary.put(st, st);
            }
        }

        cols = new StringBuilder[boardWidth];
        rows = new StringBuilder[boardWidth];

        for (int i = 0; i < boardWidth; i++) {
            cols[i] = new StringBuilder(); //fills colum array
            rows[i] = new StringBuilder(); // filld rows arrat
        }

        play(0, 0);

        System.out.print("I found " + totalSolutions + " total solutions!");

    }

    
    public void play(int r, int c) { // uses pruning from TriesSTNew class and backtracks to find all answers

        if (r == gameBoard.length) { // checks for a solution
            if (totalSolutions <= 10000) {
                System.out.println("Solution: " + totalSolutions);
                boardSolution();

            }
            totalSolutions++;
            return;
        }
        if (gameBoard[r][c] == '-') {
            rows[r].append('-');
            cols[c].append('-');
            if (c + 1 < gameBoard.length) {
                play(r, c + 1);

            } else {
                play(r + 1, 0);
            }
            rows[r].deleteCharAt(rows[r].length() - 1);
            cols[c].deleteCharAt(cols[c].length() - 1);
        } else {
            for (char ch = 'a'; ch <= 'z'; ch++) {
                if (checkPrfx(r, c, ch)) {
                    if (gameBoard[r][c] != '+') {
                        ch = gameBoard[r][c];
                    }
                    rows[r].append(ch);
                    cols[c].append(ch);

                    if (c + 1 < gameBoard.length) {

                        play(r, c + 1);
                    } else {
                        play(r + 1, 0);
                    }
                    rows[r].deleteCharAt(rows[r].length() - 1);
                    cols[c].deleteCharAt(cols[c].length() - 1);

                }
            }
        }
    }

   
    public boolean checkPrfx(int r, int c, char ch) { // checks for validity
        if (r < gameBoard.length && c < gameBoard.length) {

            if (gameBoard[r][c] != '+') {

                ch = gameBoard[r][c];

            }
            rows[r].append(ch);
            cols[c].append(ch);
        } else return false;
            
      
        String[] rowWords = rows[r].toString().split("-");
        String[] colWords = cols[c].toString().split("-");
        rows[r].deleteCharAt(rows[r].length() - 1);
        cols[c].deleteCharAt(cols[c].length() - 1);
        Boolean validCol = checkWord(rowWords, c);
        Boolean validRow = checkWord(colWords, r);
        return validCol && validRow;
    }

    
    public void boardSolution() { // just to print out each board solution
        for (int i = 0; i < rows.length; i++) {
            System.out.println(rows[i]);
        }
        System.out.println();
    }


    public boolean checkWord(String[] arr, int num) { // checks for words or if a prefix
        boolean isWord = true;
        for (int i = 0; i < arr.length; i++) {
            int ans = dictionary.searchPrefix(arr[i].toString());
            if (arr[i].length() == 0) {
                continue;
            }
            // At last spot for both both row and col must be words
            if (i < arr.length - 1 || num + 1 == gameBoard.length) {
                isWord = (ans == WRD || ans == BOTH);
            } else {
                if (ans != PRFX && ans != BOTH) {
                    isWord = false;
                }
            }
            if (isWord == false)
                return false;
        }
        return isWord;
    }
}